package com.ibm.test;

import java.io.IOException;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.ibm.pages.AdminPage;
import com.ibm.pages.EditBannerPage;
import com.ibm.pages.UserPage;
import com.ibm.utilities.PropertiesFileHandler;

public class AdminLogin {

	WebDriver driver;
	WebDriverWait wait;
	PropertiesFileHandler propFileHandler;
	HashMap<String, String> data;

	@BeforeSuite
	public void preSetForTest() throws IOException {
		String file = "./TestData/data.properties";
		propFileHandler = new PropertiesFileHandler();
		data = propFileHandler.getPropertiesAsMap(file);
	}

	@BeforeMethod
	public void Initialization() {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		driver = new ChromeDriver();
		wait = new WebDriverWait(driver, 60);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

	}

	@AfterMethod
	public void closeBrowser() {
		driver.quit();
	}

	@Test(priority = 1, testName = "ValidatingModifiedRowPresence")
	public void positiveCredential() throws IOException {

		try {
			String url = data.get("url");
			String userName = data.get("uname");
			String password = data.get("pwd");
			String banName=data.get("bannerName");
			driver.get(url);
			//String banName1=data.get("bannerName");
			

			AdminPage admin = new AdminPage(driver, wait);
			admin.enterEmailAddress(userName);
			admin.enterPassword(password);
			admin.clickOnLogin();
			
			
			
			UserPage uPage = new UserPage(driver, wait);
			uPage.clickCatalog();
			uPage.clickBanner();
			uPage.navigateToTable();
			uPage.edit();
			
			
			EditBannerPage editPage=new EditBannerPage(driver, wait);
			editPage.bannerName(banName);
			editPage.submit();
			
			uPage.clickDropDown();
			String text =uPage.getPageSrcForModifiedRow();
			Assert.assertTrue(text.contains(banName), "Assertion on required field Message");

			Reporter.log("Modified element is Present");
		} catch (Exception e) {
			
			System.out.println(e.getMessage());
			Reporter.log("Modified element is not Present");
			//screenshot
			//throw e;
			Assert.fail();
		}	
	}
  
}
